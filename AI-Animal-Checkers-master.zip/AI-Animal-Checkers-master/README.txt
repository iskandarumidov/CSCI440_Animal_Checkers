# AI-Animal-Checkers
Animal Checkers Game (SEF and minimax)
