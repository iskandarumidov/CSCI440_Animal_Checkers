package com.wolfe.boardbuilding;

import android.app.Activity;
import android.os.Bundle;

public class Winner extends Activity{

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.winner);
	    
    
	}

}
